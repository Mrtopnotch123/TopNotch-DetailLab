(() => {
  "use strict";
  const $=(s,r=document)=>r.querySelector(s);
  const $$=(s,r=document)=>[...r.querySelectorAll(s)];

  const header=$("#header"), menu=$("#menu"), menuBtn=$("#menuBtn"), topBtn=$("#top");

  function scrollUI(){
    header?.classList.toggle("scrolled",scrollY>20);
    topBtn?.classList.toggle("show",scrollY>700);
  }
  addEventListener("scroll",scrollUI,{passive:true});
  scrollUI();

  menuBtn?.addEventListener("click",()=>{
    const open=menu.classList.toggle("open");
    menuBtn.setAttribute("aria-expanded",String(open));
    document.body.classList.toggle("menu-open",open);
  });
  $$("#menu a").forEach(a=>a.addEventListener("click",()=>{
    menu.classList.remove("open");
    document.body.classList.remove("menu-open");
    menuBtn?.setAttribute("aria-expanded","false");
  }));
  topBtn?.addEventListener("click",()=>scrollTo({top:0,behavior:"smooth"}));

  if("IntersectionObserver" in window){
    const observer=new IntersectionObserver(entries=>{
      entries.forEach(entry=>{
        if(entry.isIntersecting){
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },{threshold:.12});
    $$(".reveal").forEach(el=>observer.observe(el));
  } else {
    $$(".reveal").forEach(el=>el.classList.add("visible"));
  }

  $$(".faqs article button").forEach(btn=>btn.addEventListener("click",()=>{
    const item=btn.closest("article");
    $$(".faqs article").forEach(other=>other!==item&&other.classList.remove("open"));
    item.classList.toggle("open");
  }));

  const prices={
    "Quick Clean":{car:35,suv:45,xl:55},
    "Refresh":{car:70,suv:85,xl:100},
    "Deep Clean":{car:120,suv:145,xl:165},
    "Restoration":{car:180,suv:210,xl:240},
    "Recovery":{car:275,suv:325,xl:375}
  };
  const vehicleNames={car:"Car",suv:"SUV / Truck",xl:"3-row / Van / Large Truck"};
  const packageSelect=$("#package");
  const vehicleSelect=$("#vehicle");
  const addonChecks=$$(".addons input");
  const total=$("#total"), desc=$("#desc"), lineItems=$("#lineItems"), warning=$("#warning");

  function updateEstimate(){
    const pkg=packageSelect.value;
    const vehicle=vehicleSelect.value;
    const base=prices[pkg][vehicle];
    const selected=addonChecks.filter(x=>x.checked);
    const extras=selected.reduce((sum,x)=>sum+Number(x.dataset.price),0);
    const amount=base+extras;
    total.textContent=`$${amount}${pkg==="Recovery"?"+":""}`;
    desc.textContent=`${pkg} · ${vehicleNames[vehicle]}`;
    lineItems.innerHTML=`<span>Base service</span><strong>$${base}</strong>`+
      selected.map(x=>`<span>${x.dataset.name}</span><strong>+$${x.dataset.price}${/Pet hair|stain|Odor|Headliner|Trunk/.test(x.dataset.name)?"+":""}</strong>`).join("");
    warning.textContent=pkg==="Recovery"
      ?"Recovery requires photo review. This amount is a minimum starting point, not a final quote."
      :"Final price depends on actual vehicle size, condition and labor. Severe conditions may require Restoration or Recovery.";
  }
  [packageSelect,vehicleSelect,...addonChecks].forEach(el=>el?.addEventListener("change",updateEstimate));
  $("#reset")?.addEventListener("click",()=>{
    vehicleSelect.value="car";
    packageSelect.value="Deep Clean";
    addonChecks.forEach(x=>x.checked=false);
    updateEstimate();
  });
  updateEstimate();

  function openBooking(pkg,estimate=""){
    $("#bookPackage").value=pkg;
    $("#estimateValue").value=estimate;
    $("#booking").scrollIntoView({behavior:"smooth"});
  }
  $$(".choose").forEach(btn=>btn.addEventListener("click",()=>openBooking(btn.dataset.package)));
  $("#bookEstimate")?.addEventListener("click",()=>{
    const extras=addonChecks.filter(x=>x.checked).map(x=>x.dataset.name).join(", ");
    openBooking(packageSelect.value,`${desc.textContent}; website estimate ${total.textContent}${extras?`; add-ons: ${extras}`:""}`);
  });

  $("#quiz")?.addEventListener("submit",e=>{
    e.preventDefault();
    const condition=$("#qCondition").value;
    const last=$("#qLast").value;
    const issues=$$('input[name="issue"]:checked').map(x=>x.value);
    if(!condition)return;

    let pkg="Refresh";
    let reason="A thorough maintenance clean fits the condition you selected.";

    if(condition==="light"&&issues.length===0&&last==="recent"){
      pkg="Quick Clean";
      reason="Your vehicle sounds lightly soiled and regularly maintained.";
    } else if(condition==="average"&&issues.length===0){
      pkg="Refresh";
      reason="Your interior sounds like a normal maintenance-clean candidate.";
    } else if(condition==="average"||condition==="dirty"){
      pkg="Deep Clean";
      reason="The condition calls for more than a surface clean, but may not need full extraction.";
    }
    if(issues.some(x=>["stains","pet","odor"].includes(x))&&(condition==="dirty"||issues.length>=2)){
      pkg="Restoration";
      reason="The condition and problem areas likely require extraction or extended treatment.";
    }
    if(condition==="severe"||(issues.includes("trash")&&issues.length>=2)){
      pkg="Recovery";
      reason="A photo-based custom quote is safest for the labor and condition described.";
    }

    const result=$("#quizResult");
    result.innerHTML=`<strong>${pkg}</strong><p>${reason}</p><button type="button" class="btn primary full" id="quizBook">Choose ${pkg}</button>`;
    result.classList.add("show");
    $("#quizBook").addEventListener("click",()=>openBooking(pkg));
  });

  const slider=$("#slider"),before=$("#before"),divider=$("#divider");
  slider?.addEventListener("input",()=>{
    before.style.width=`${slider.value}%`;
    divider.style.left=`${slider.value}%`;
    const ba=slider.closest(".ba");
    ba.style.setProperty("--split",`${slider.value}%`);
  });

  $("#bookingForm")?.addEventListener("submit",e=>{
    e.preventDefault();
    const status=$("#status");
    const fields=[$("#name"),$("#phone"),$("#bookVehicle"),$("#bookPackage"),$("#date"),$("#location"),$("#consent")];
    if(fields.some(x=>x.type==="checkbox"?!x.checked:!x.value.trim())){
      status.textContent="Please complete every required field.";
      status.className="error";
      return;
    }
    const estimate=$("#estimateValue").value;
    const body=[
      "Hi TopNotch Detail Lab, I would like to request an appointment.",
      "",
      `Name: ${$("#name").value}`,
      `Phone: ${$("#phone").value}`,
      `Vehicle: ${$("#bookVehicle").value}`,
      `Package: ${$("#bookPackage").value}`,
      `Preferred date: ${$("#date").value}`,
      `Location: ${$("#location").value}`,
      estimate?`Website estimate: ${estimate}`:"",
      `Condition / concerns: ${$("#notes").value||"None listed"}`,
      "",
      "I understand the appointment and final price must be confirmed."
    ].filter(Boolean).join("\n");
    location.href=`sms:+13177901060?&body=${encodeURIComponent(body)}`;
  });

  const tomorrow=new Date();
  tomorrow.setDate(tomorrow.getDate()+1);
  const minDate=`${tomorrow.getFullYear()}-${String(tomorrow.getMonth()+1).padStart(2,"0")}-${String(tomorrow.getDate()).padStart(2,"0")}`;
  $("#date")?.setAttribute("min",minDate);
  $("#year").textContent=new Date().getFullYear();
  $$('a[target="_blank"]').forEach(a=>a.rel="noopener noreferrer");
})();