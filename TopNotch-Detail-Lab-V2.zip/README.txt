TOPNOTCH DETAIL LAB V2 — INSTALLATION

Keep this exact image path in your repository:
assets/topnotch-logo.png

Replace these three existing repository files:
1. index.html
2. style.css
3. script.js

Then commit the changes. Vercel should deploy automatically.

INCLUDED
- Redesigned luxury black/chrome/red layout
- One-time logo light sweep
- Five startup-friendly service packages
- Accurate package boundaries
- Package comparison table
- Package recommendation quiz
- Vehicle selector
- Live estimate calculator
- Add-ons
- Estimate transferred into booking
- SMS booking request
- Before/after slider shell
- Mobile navigation and bottom action bar
- FAQ accordion
- SEO basics and responsive design

NOT INCLUDED BY REQUEST
- Chemical/product section
- TopNotch cleaning process or secret method

GALLERY
The gallery currently contains placeholders. Add your own matching before-and-after photos when ready.

IMPORTANT
Website prices are starting estimates. Confirm the final amount before performing work.
Only direct customers to PayPal after the appointment and payment amount are confirmed.
