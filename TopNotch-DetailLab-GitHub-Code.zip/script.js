(() => {
  "use strict";

  const PHONE = "+13177901060";

  const packageBase = {
    "Quick Reset": 40,
    "Full Reset": 90,
    "Deep Reset": 180
  };

  const includedAddons = {
    "Quick Reset": [],
    "Full Reset": [],
    "Deep Reset": ["Cargo Area Reset", "Spot Extraction", "Leather Conditioning"],
    "Recovery": ["Cargo Area Reset", "Spot Extraction", "Leather Conditioning", "Pet Hair Removal", "Odor Treatment"]
  };

  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];

  const header = $("#siteHeader");
  const progress = $("#scrollProgress");
  const backToTop = $("#backToTop");
  const cursorGlow = $("#cursorGlow");

  const updateScrollUI = () => {
    const scrollTop = window.scrollY;
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
    const percent = maxScroll > 0 ? (scrollTop / maxScroll) * 100 : 0;

    progress.style.width = `${percent}%`;
    header.classList.toggle("scrolled", scrollTop > 30);
    backToTop.classList.toggle("show", scrollTop > 650);
  };

  window.addEventListener("scroll", updateScrollUI, { passive: true });
  updateScrollUI();

  if (window.matchMedia("(hover: hover) and (pointer: fine)").matches) {
    window.addEventListener(
      "pointermove",
      (event) => {
        cursorGlow.style.opacity = "1";
        cursorGlow.style.left = `${event.clientX}px`;
        cursorGlow.style.top = `${event.clientY}px`;
      },
      { passive: true }
    );
  }

  backToTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  const menuToggle = $("#menuToggle");
  const siteNav = $("#siteNav");

  menuToggle.addEventListener("click", () => {
    const open = siteNav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(open));
  });

  $$("#siteNav a").forEach((link) => {
    link.addEventListener("click", () => {
      siteNav.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
    });
  });

  const revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          revealObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );

  $$(".reveal").forEach((element) => revealObserver.observe(element));

  const estimatePackage = $("#estimatePackage");
  const estimateChecks = $$("[data-addon]", $("#priceEstimator"));
  const estimateTotal = $("#estimateTotal");
  const estimateNote = $("#estimateNote");

  const bookingForm = $("#bookingForm");
  const bookPackage = $("#bookPackage");
  const bookingAddons = $$('input[name="addons"]', bookingForm);
  const bookingSummary = $("#bookingSummary");
  const bookingProgress = $("#bookingProgress");

  const updateEstimator = () => {
    const selectedPackage = estimatePackage.value;
    const lockedAddons = includedAddons[selectedPackage] || [];

    estimateChecks.forEach((input) => {
      const shouldDisable = lockedAddons.includes(input.dataset.addon);

      input.disabled = shouldDisable;

      if (shouldDisable) {
        input.checked = false;
      }

      input.closest("label").classList.toggle("is-disabled", shouldDisable);
    });

    if (selectedPackage === "Recovery") {
      estimateTotal.textContent = "Custom quote";
      estimateNote.textContent = "Recovery requires photos or an inspection before pricing.";
      return;
    }

    const addonTotal = estimateChecks
      .filter((input) => input.checked && !input.disabled)
      .reduce((sum, input) => sum + Number(input.value), 0);

    const basePrice = packageBase[selectedPackage] || 0;

    estimateTotal.textContent =
      selectedPackage === "Quick Reset" && addonTotal === 0
        ? `$${basePrice}`
        : `$${basePrice + addonTotal}+`;

    estimateNote.textContent =
      "Final pricing depends on vehicle size, condition, materials, and labor.";
  };

  const updateBookingAddons = () => {
    const lockedAddons = includedAddons[bookPackage.value] || [];

    bookingAddons.forEach((input) => {
      const shouldDisable = lockedAddons.includes(input.value);

      input.disabled = shouldDisable;

      if (shouldDisable) {
        input.checked = false;
      }

      input.closest("label").classList.toggle("is-disabled", shouldDisable);
      input.closest("label").title = shouldDisable
        ? "Included in your selected package"
        : "";
    });
  };

  const updateBookingSummary = () => {
    const packageName = bookPackage.value;
    const selectedAddons = bookingAddons
      .filter((input) => input.checked && !input.disabled)
      .map((input) => input.value);

    if (!packageName) {
      bookingSummary.textContent = "Select a package to begin your booking summary.";
      return;
    }

    const price =
      packageName === "Recovery"
        ? "Custom quote"
        : packageName === "Quick Reset"
          ? "$40"
          : `From $${packageBase[packageName]}`;

    bookingSummary.innerHTML = `<strong>${packageName}</strong> · ${price}${
      selectedAddons.length ? `<br>Add-ons: ${selectedAddons.join(", ")}` : ""
    }`;
  };

  const updateBookingProgress = () => {
    const requiredFields = $$("[required]", bookingForm);

    const completedFields = requiredFields.filter((field) => {
      if (field.type === "checkbox") {
        return field.checked;
      }

      return String(field.value).trim() !== "";
    }).length;

    bookingProgress.style.width = `${(completedFields / requiredFields.length) * 100}%`;
  };

  $$(".package-select").forEach((button) => {
    button.addEventListener("click", () => {
      const packageName = button.dataset.package;

      bookPackage.value = packageName;
      estimatePackage.value = packageName;

      updateEstimator();
      updateBookingAddons();
      updateBookingSummary();

      $("#book").scrollIntoView({ behavior: "smooth" });
    });
  });

  $("#packageFinder").addEventListener("submit", (event) => {
    event.preventDefault();

    const condition = $("#finderCondition").value;
    const specialCondition = $("#finderSpecial").value;

    let packageName = "";
    let recommendation = "";

    if (condition === "severe" || specialCondition === "heavy") {
      packageName = "Recovery";
      recommendation =
        "Recovery photo review recommended. The condition sounds beyond a normal package and should be assessed before pricing.";
    } else if (condition === "deep" || specialCondition === "some") {
      packageName = "Deep Reset";
      recommendation =
        "Deep Reset is the strongest starting match for an interior needing detailed cleaning, extraction, or additional correction.";
    } else if (condition === "normal") {
      packageName = "Full Reset";
      recommendation =
        "Full Reset is the TopNotch Recommended choice for normal everyday buildup.";
    } else {
      packageName = "Quick Reset";
      recommendation =
        "Quick Reset fits a maintained interior that only needs trash removal and vacuuming.";
    }

    $("#finderResult").textContent = recommendation;

    bookPackage.value = packageName;
    estimatePackage.value = packageName;

    updateEstimator();
    updateBookingAddons();
    updateBookingSummary();
  });

  estimatePackage.addEventListener("change", updateEstimator);

  estimateChecks.forEach((input) => {
    input.addEventListener("change", updateEstimator);
  });

  $("#useEstimate").addEventListener("click", () => {
    bookPackage.value = estimatePackage.value;

    const selectedEstimateAddons = estimateChecks
      .filter((input) => input.checked && !input.disabled)
      .map((input) => input.dataset.addon);

    bookingAddons.forEach((input) => {
      input.checked = selectedEstimateAddons.includes(input.value);
    });

    updateBookingAddons();
    updateBookingSummary();

    $("#book").scrollIntoView({ behavior: "smooth" });
  });

  bookPackage.addEventListener("change", () => {
    updateBookingAddons();
    updateBookingSummary();
    updateBookingProgress();
  });

  bookingAddons.forEach((input) => {
    input.addEventListener("change", updateBookingSummary);
  });

  $$("input, select, textarea", bookingForm).forEach((field) => {
    field.addEventListener("input", updateBookingProgress);
    field.addEventListener("change", updateBookingProgress);
  });

  const today = new Date();
  const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
    .toISOString()
    .split("T")[0];

  $("#bookDate").min = localDate;

  bookingForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const status = $("#bookingStatus");

    if (!bookingForm.checkValidity()) {
      bookingForm.reportValidity();
      status.textContent = "Please complete every required field.";
      return;
    }

    const selectedAddons = bookingAddons
      .filter((input) => input.checked && !input.disabled)
      .map((input) => input.value);

    const message = [
      "TOPNOTCH DETAILLAB — BOOKING REQUEST",
      "",
      `Name: ${$("#bookName").value.trim()}`,
      `Phone: ${$("#bookPhone").value.trim()}`,
      `Vehicle: ${$("#vehicleYear").value.trim()} ${$("#vehicleMake").value.trim()} ${$("#vehicleModel").value.trim()}`,
      `Vehicle type: ${$("#vehicleType").value}`,
      `Package: ${bookPackage.value}`,
      `Add-ons: ${selectedAddons.length ? selectedAddons.join(", ") : "None"}`,
      `Preferred date: ${$("#bookDate").value}`,
      `Preferred time: ${$("#bookTime").value}`,
      `Location: ${$("#bookLocation").value.trim()}`,
      `Condition: ${$("#bookCondition").value}`,
      `Pet hair: ${$("#bookPetHair").value}`,
      `Odor: ${$("#bookOdor").value}`,
      `Spills/staining: ${$("#bookStains").value}`,
      `Notes: ${$("#bookNotes").value.trim() || "None"}`,
      "",
      "I understand this request does not confirm an appointment or final price."
    ].join("\n");

    status.textContent =
      "Opening your messaging app with the booking request prepared.";

    window.location.href = `sms:${PHONE}?&body=${encodeURIComponent(message)}`;
  });

  $("#reviewForm").addEventListener("submit", (event) => {
    event.preventDefault();

    const reviewForm = event.currentTarget;
    const status = $("#reviewStatus");

    if (!reviewForm.checkValidity()) {
      reviewForm.reportValidity();
      status.textContent = "Please complete the required review fields.";
      return;
    }

    const rating = $('input[name="rating"]:checked', reviewForm)?.value || "";

    const message = [
      "TOPNOTCH DETAILLAB — CUSTOMER REVIEW",
      "",
      `Name: ${$("#reviewName").value.trim()}`,
      `Service: ${$("#reviewService").value}`,
      `Rating: ${rating}/5`,
      `Review: ${$("#reviewText").value.trim()}`,
      `Permission to feature: ${$("#reviewPermission").checked ? "Yes" : "No"}`
    ].join("\n");

    status.textContent = "Opening your messaging app with the review prepared.";

    window.location.href = `sms:${PHONE}?&body=${encodeURIComponent(message)}`;
  });

  $("#currentYear").textContent = String(new Date().getFullYear());

  updateEstimator();
  updateBookingAddons();
  updateBookingSummary();
  updateBookingProgress();
})();
