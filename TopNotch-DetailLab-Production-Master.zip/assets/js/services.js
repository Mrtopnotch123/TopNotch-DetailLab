(() => {
  "use strict";
  const finder = document.querySelector("#packageFinder");
  const result = document.querySelector("#finderResult");
  const action = document.querySelector("#finderAction");
  let recommendation = "";

  function savePreset(name, price) {
    const existing = sessionStorage.getItem("topnotchSelection");

    if (existing) {
      try {
        const parsed = JSON.parse(existing);
        const isCustom =
          parsed?.mode === "custom" ||
          parsed?.mode === "assessment";

        if (
          isCustom &&
          !confirm(
            `Switching to ${name} will replace your current custom selection. Continue?`
          )
        ) {
          return;
        }
      } catch {}
    }

    sessionStorage.setItem("topnotchSelection", JSON.stringify({
      mode: "preset",
      package: name,
      price: price ? Number(price) : null,
      services: [],
      assessmentRequired: name === "Recovery"
    }));

    location.href = "../book/";
  }

  document.querySelectorAll(".preset-choice").forEach(button => {
    button.addEventListener("click", () => savePreset(button.dataset.package, button.dataset.price));
  });

  finder?.addEventListener("submit", event => {
    event.preventDefault();
    if (!finder.checkValidity()) return finder.reportValidity();
    const condition = document.querySelector("#finderCondition").value;
    const special = document.querySelector("#finderSpecial").value;

    if (condition === "severe" || special === "heavy") {
      recommendation = "Recovery";
      result.innerHTML = "<strong>Recovery assessment fits best.</strong><br>Your answers indicate severe conditions that require photos and review before pricing.";
    } else if (condition === "deep" || special === "some") {
      recommendation = "Deep Reset";
      result.innerHTML = "<strong>Deep Reset fits best.</strong><br>Your interior needs detailed cleaning or material-specific care beyond routine service.";
    } else if (condition === "normal") {
      recommendation = "Full Reset";
      result.innerHTML = "<strong>Full Reset fits best.</strong><br>Your vehicle sounds like it has normal everyday buildup and needs a complete interior cleaning.";
    } else {
      recommendation = "Quick Reset";
      result.innerHTML = "<strong>Quick Reset fits best.</strong><br>Your maintained interior appears to need a vacuum and light surface refresh.";
    }
    action.textContent = recommendation === "Recovery" ? "Request Recovery Assessment" : `Choose ${recommendation}`;
    action.classList.remove("hidden");
  });

  action?.addEventListener("click", () => {
    const prices = { "Quick Reset": 40, "Full Reset": 75, "Deep Reset": 150 };
    savePreset(recommendation, prices[recommendation] ?? "");
  });
})();
